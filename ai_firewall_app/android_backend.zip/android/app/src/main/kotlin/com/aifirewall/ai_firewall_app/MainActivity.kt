package com.aifirewall.ai_firewall_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
